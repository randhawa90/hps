
public enum HunterMoves {
  NE,NW,SE,SW,NEw,NWw,SEw,SWw,NEwx,NWwx,SEwx,SWwx;
}
