
public enum PreyMoves {
  NN,SS,EE,WW,NE,SE,NW,SW,ZZ;
}
